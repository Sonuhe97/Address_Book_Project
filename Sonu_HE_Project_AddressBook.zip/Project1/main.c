/*Author: Sonu H E
Date: 25/09/2024
Description: 1. To create an AddressBook with maximum capacity of 100 contacts using array of structures.
             3. Three Informations are being used to create a contact i.e
                a)Name
                b)Phone number
                c)e-mail ID
             2. Various tasks like searching, editing, deleting and listing the contact details of perticular
                individual or the whole AddressBook can be done based on users wish.*/

#include <stdio.h>
#include "contact.h"
#include "file.h"


int main() {
    int choice;
    AddressBook addressBook;
    initialize(&addressBook); // Initialize the address book

/*Displaying the menu to user, to choose choose which operation they like to perform*/
    do {
        printf("\nAddress Book Menu:\n");
        printf("1. Create contact\n");
        printf("2. Search contact\n");
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List all contacts\n");
        printf("6. Save and Exit\n");
        printf("Enter your choice: ");

        scanf("%d", &choice);//Based on the user entry calling the respective functions
        
        switch (choice) 
		{
            case 1:
                createContact(&addressBook);//Function call to createContact
                break;
            case 2:
                searchContact(&addressBook);//Function call to searchContact
                break;
            case 3:
                editContact(&addressBook);//Function call to editContact
                break;
            case 4:
                deleteContact(&addressBook);//Function call to deleteContact
                break;
            case 5:
                listContacts(&addressBook);//Function call to listContacts in sorted order
                break;
            case 6:
                saveContactsToFile(&addressBook);//Function call to save the contents in AddressBook to file
                printf("Saving and Exiting...\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");//Displaying error message if choice is invalid
        }
    } while (choice != 6);
    
       return 0;
}
