#include <stdio.h>
#include "file.h"

/*Function definition to save the contents in the AddressBook structure to the file*/
void saveContactsToFile(AddressBook *addressBook)
{
     FILE *fp;
     int i;
     fp = fopen("contacts.csv","w");/*Opening the file in write mode to write the new contents along with changes
     to the previously present data */
     if(fp == NULL)
     {
      printf("File doesn't exist\n");//File validation
      return;
     }
     /*Writing all the data in the AddressBook to the file*/
     fprintf(fp,"%d\n",addressBook->contactCount);
     for(i = 0; i < addressBook->contactCount; i++)
     {
       fprintf(fp,"%s,%s,%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);     
     }
     fclose(fp);
}

/*Function definition to load the contants in the file to the AddressBook before performing any operation*/
void loadContactsFromFile(AddressBook *addressBook) 
{
    FILE *fp;
    fp = fopen("contacts.csv","r");
    if(fp == NULL)
    {
      printf("File doesn't exist");
      return ;
    }
    fscanf(fp,"%d ",&addressBook->contactCount);
    //printf("%ld\n",ftell(fp));
    int i;
    for(i = 0;i < addressBook->contactCount; i++)
    {
      fscanf(fp,"%[^,],%[^,],%[^\n] ",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    fclose(fp);
    
}
