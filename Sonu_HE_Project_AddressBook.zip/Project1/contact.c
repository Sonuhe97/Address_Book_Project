/*Header files need to be included as it contains prototypes of various built-in functions and 
some user defined functions*/
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
#include <ctype.h>
#include <stdio_ext.h>

/*Prototypes of various functions that are being used further*/
void displaycontact(AddressBook *addressBook, int i);
int validate_name(char *n);
int validate_phone(AddressBook *addressBook,char *p);
int validate_email(AddressBook *addressBook, char *e);
int searchcontactedit(AddressBook *addressBook);
int editmenu();
void sortcontact(AddressBook *a,int c);
void displayline();


/*Definition of initialize function where the contents in the .csv file is being loaded
to the AddressBook structure*/

void initialize(AddressBook *addressBook)
{
    addressBook->contactCount = 0;
    //populateAddressBook(addressBook);
  // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);
}


/*Definition of creatContact function */
void createContact(AddressBook *addressBook)
{
  //Take temporay variables to read the data from user, only after validating we are stroring it in structure
    char n[50], p[20],e[50];
    int flag = 1;

  //Step1: Read a name from user
  //step2: validate the name->alphabets or space
  //true->goto step3, false->print error,goto step1

   while(flag)
  {
      printf("Enter the name: ");
      scanf(" %[^\n]",n);
      __fpurge(stdin);
      flag = validate_name(n);     
  }
     
  //step3: read mobile number
  //step4:validate the mobile number->digit & 10 digits & unique
  //true->goto step5, false-> print error,goto step 3

  flag = 1;
  while(flag)
  {
      printf("Enter mobile number(0-9): ");
      scanf(" %[^\n]",p);
      __fpurge(stdin);
      flag = validate_phone(addressBook,p);
  }
 
  //step5: read email id
  //step6->validate->@gmail.com & unique 
  //true->goto step7, false-> print error, goto step5

  flag = 1;
  while(flag)
  {
      printf("Enter the e_mail ID: ");
      scanf(" %[^\n]",e);
      __fpurge(stdin);
      flag = validate_email(addressBook,e);
    
  }

  //step7: store into structure[contact_count]

     strcpy(addressBook->contacts[addressBook->contactCount].name,n);
     strcpy(addressBook->contacts[addressBook->contactCount].phone,p);
     strcpy(addressBook->contacts[addressBook->contactCount].email,e);

     printf("Contact is created successfully\n");
  //Displaying the contact details after it is created
     displaycontact(addressBook,addressBook->contactCount);
  //Incrementing the contacts count
     addressBook->contactCount++; 
     sortcontact(addressBook,addressBook->contactCount);   
}

/*Logic to search contact*/
void searchContact(AddressBook *addressBook) 
{
    //Making use of local variables to read data from the user and to perform requested operation
    
    char n[50],p[20],e[20];
    int flag = 1,key,i;
    char ch;
    
    while(flag)
    {
      //step1: Print the menu based on what search should be done
      printf("Based on what data you like to search: \n");
      printf(" 1.Name\n 2.Mobile no\n 3.e-mail ID\n 4.Exit menu\n");
      //Choose from menu
      printf("Please enter the key: ");
      scanf("%d",&key);

      //Go to the respective menu based on switch expression
      switch(key)
      {
        //Read the name from the user and check whether it is present
        //yes->Print the complete details
        //No->Display error and goto menu

        case 1:
        printf("Enter the name: ");
        scanf(" %[^\n]",n);
        __fpurge(stdin);
        for(i = 0; i <= addressBook->contactCount; i++)
        {
          flag = 1;
          //Searching the name in the AddressBook structure
          int res = strcasecmp(addressBook->contacts[i].name,n);
          if(res == 0)
          {
            flag = 0;
            displaycontact(addressBook,i);
            break;
          }
          //Giving suggestions to the user based on the entered subdtring to make the search easy
          char *found = strcasestr(addressBook->contacts[i].name,n);
          if(found != NULL)
          {
            printf("Is this the contact you are searching?\n");
            displaycontact(addressBook,i);
            printf("If yes enter 'Y'\n"); //Getting the confirmation from the user
            scanf(" %c",&ch);
            if(ch == 'Y' || ch == 'y')
            {
            flag = 0;
            printf("Contact found\n");
            return;  
            }
            else
            {
            found = NULL;
            continue;
            }
          }
        }
        //If the entered name is not present then displaying the error message
        if(flag == 1)  
        {
        printf("Entered name is invalid or not found.\n");
        }
        break;
        
        //Read the mobile number from the user and check whether it is present
        //yes->Print the complete details
        //No->Display error and goto menu

        case 2:
        printf("Enter the mobile number: ");
        scanf(" %[^\n]",p);
        __fpurge(stdin);
        for(i = 0; i <= addressBook->contactCount; i++)
        {
          flag = 1;
          //Searching the phone number in the AddressBook structure
          int res = strcmp(addressBook->contacts[i].phone,p);
          if(res == 0)
          {
            flag = 0;
            displaycontact(addressBook,i);
            break;
          }  
        }
        if(flag == 1)
        {
        printf("Entered Mobile number is invalid or not found.\n");
        }
        break;
        
        //Read the e-mail ID from the user and check whether it is present
        //yes->Print the complete details
        //No->Display error and goto menu

        case 3:
        printf("Enter the e-mail ID: ");
        scanf(" %[^\n]",e);
        __fpurge(stdin);
        for(i = 0; i <= addressBook->contactCount; i++)
        {
          flag = 1;
          //Searching the email in the AddressBook structure
          int res = strcmp(addressBook->contacts[i].email,e);
          if(res == 0)
          {
            flag = 0;
            displaycontact(addressBook,i);
            break;
          }  
          char *found = strcasestr(addressBook->contacts[i].email,e);
          if(found != NULL)
          {
            printf("Is this the contact you are searching?\n");
            displaycontact(addressBook,i);
            printf("If yes enter 'Y'\n"); //Getting the confirmation from the user
            scanf(" %c",&ch);
            if(ch == 'Y' || ch == 'y')
            {
            flag = 0;
            printf("Contact found\n");
            return;  
            }
            else
            {
            found = NULL;
            continue;
            }
          }
        }
        if(flag == 1)
        {
        printf("Entered e-mail ID is invalid or not found.\n");
        }
        break;

        case 4:
        flag = 0;
        break;

        default:
        printf("Please enter valid key(1-4)\n");
      }
    }

}

/*Logic to edit the contact that is already present*/
void editContact(AddressBook *addressBook)
{

  //Step1: Search the contat
  int index,key,flag = 1,ret;
  char n[50],p[20],e[30];
  
   index = searchcontactedit(addressBook);//Recieving the index value of the contact to edit 

   while(flag)
   {
   //Present->Display menu to edit
   key = editmenu();
   //Based on the key value edit name, mobile number or email
   switch(key)
   {
           case 1:
           printf("Enter the new name: ");
           scanf(" %[^\n]",n);
           ret = validate_name(n);//Validating the newly entered name
           if(ret == 0)
           {
            flag = 0;
            strcpy(addressBook->contacts[index].name,n);//Updating the new name to the structure
            printf("After updating new data is: \n");
            displaycontact(addressBook,index);//Displaying the contact details after modification
           }
           break;

           case 2:
           printf("Enter the new Mobile No: ");
           scanf(" %[^\n]",p);
           ret = validate_phone(addressBook,p);//Validating the newly entered phone number
           if(ret == 0)
           {
            flag = 0;
            strcpy(addressBook->contacts[index].phone,p);//Updating the new phone number to the structure
            printf("After updating new data is: \n");
            displaycontact(addressBook,index);//Displaying the contact details after modification
           }
           break;

           case 3:
           printf("Enter the new e-mail ID: ");
           scanf(" %[^\n]",e);
           ret = validate_email(addressBook,e);//Validating the newly entered email
           if(ret == 0)
           {
            flag = 0;
            strcpy(addressBook->contacts[index].email,e);//Updating the new email to the structure
            printf("After updating new data is: \n");
            displaycontact(addressBook,index);//Displaying the contact details after modification
           }
           break;

           case 4:
           flag = 0;
           break;

           default:
           printf("Please enter valid key(1-4)\n");
   }
   }
   sortcontact(addressBook,addressBook->contactCount);   
}

/*Logic to delete contact*/
void deleteContact(AddressBook *addressBook)
{

  int i; char key;
  int index = searchcontactedit(addressBook);//Recieving the index of the contact to delete 
  if(index >= 0)
  {
    printf("Are you sure you want to delete(Y/N)?\n");//Getting confirmation from the user to delete
    scanf(" %c",&key);
    if(key == 'Y' || key == 'y')
    {
    printf("Contact %s has been deleted successfully\n",addressBook->contacts[index].name);
    for(i = index; i < addressBook->contactCount; i++)
    {
      /*strcpy(addressBook->contacts[i].name,addressBook->contacts[i+1].name);
      strcpy(addressBook->contacts[i].phone,addressBook->contacts[i+1].phone);
      strcpy(addressBook->contacts[i].email,addressBook->contacts[i+1].email);*/
      addressBook->contacts[i]=addressBook->contacts[i+1];
    }
    addressBook->contactCount--;//After deleting decrementing the contact counts value
    }
    else
    printf("Delete contact process is denied");
  }
  else
  {
    printf("Deleting the contact is failed\n");
  } 
     
}

/*Logic to list contacts*/
void listContacts(AddressBook *addressBook) 
{
    // Sort contacts based on the chosen criteria i.e in alphabetical order
    int i;
    sortcontact(addressBook,addressBook->contactCount);
    printf("Complete Details of the contact:\n");
    displayline();
    printf("Sl.No   Name                 Phone No.       e-mail ID\n");
    displayline();
    //Running a loop to list all the contacts in the AddressBook structure
    for(i = 0; i < addressBook->contactCount; i++)
    {
      printf("%3d.  %-20s  %10s   %s\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
} 

/*Function definition for displaying the contcat*/
void displaycontact(AddressBook *addressBook, int i)
{
  printf("Contact details: \n");
  printf("1. Name: %s\n",addressBook->contacts[i].name);
  printf("2.Phone: %s\n",addressBook->contacts[i].phone);
  printf("3.email: %s\n",addressBook->contacts[i].email);
}

/*Function definition for validating the name for its alphabetical character with space or not*/
int validate_name(char *n)
{
  int i, c = 0;
        for(i = 0; n[i] != '\0'; i++)
        {
            if(isalpha(n[i]) || n[i] == ' ')//Making use of in-built isalpha function to count alpha and space
            c++;
        }
        if(c == strlen(n))//Comparing count with lenghth of the string to assure that entered name is valid
        {
            return 0;
        }
        else
        {
          printf("Invalid username, Please enter valid name.\n");//Invalid name->Error message
          printf("Name should contain only A-Z,a-z,space\n"); 
          return 1;
        }   
}

/*Function definition for validating the phone number for its uniqueness and 10-digit numeric string*/
int validate_phone(AddressBook *addressBook,char *p)
{
   int i,c = 0;
        for(i = 0; p[i] != '\0'; i++)
        {
            if(isdigit(p[i]))//Making use of inbuilt isdigit function and counting number of digits in string
            c++;
        }
        if(c == 10)//If phone number is valid 10 digit then checking for its uniqueness
        {
           for(i = addressBook->contactCount; i >= 0; i--)
            {
                int res = strcmp(addressBook->contacts[i].phone,p);
                if(res == 0)
                {
                  printf("Entered mobile number is already present\n");
                  return 1;
                }
            }
            return 0;        
        }
        else
        {
            printf("Please enter valid 10 digit mobile number\n");//Invalid phone number-> Error message
            return 1;
        } 
}

/*Function definition for validating the email for its uniqueness and to be ended with "@gmail.com" */
int validate_email(AddressBook *addressBook, char *e)
{
      int i;
      //char em[20] = "@gmail.com";
      char *f = strrchr(e,'@');//Using strrchr function to check last occurance of '@' character in string
      if(f != NULL)
      {
        int res = strcmp("@gmail.com",f);//Checking whether the string is ended with "@gmail.com"
        if(res == 0)
        {
          for(i = addressBook->contactCount; i >= 0; i--)//Checking whether entered email is present or not
          {
            int res = strcmp(addressBook->contacts[i].email,e);
            if(res == 0)
            {
                printf("Entered e-mail is already present\n");
                return 1;
            }
          }
          return 0; 
        }
        else
        {
          printf("Please enter valid e-mail\n");
          return 1;
        }
      }
      else
      {
      printf("Please enter valid e-mail\n");
      return 1;
      }
}

/*Function definition for searching the contact either to edit or delete the contact and returning the
index value for futher operations*/
int searchcontactedit(AddressBook *addressBook) 
{
    /* Define the logic for search */
    
    char n[50],p[20],e[20];
    int flag = 1,key,i;
    char ch;
    
    while(flag)
    {
      //step1: Print the menu based on what search should be done
      printf("Search the contact based on any of the following to edit/delete: \n");
      printf(" 1.Name\n 2.Mobile no\n 3.e-mail ID\n");
      //Choose from menu
      printf("Please enter the key: ");
      scanf("%d",&key);
      switch(key)
      {
        case 1:
        //Read the name from the user and check whether it is present
        //yes->Print the complete details
        //No->Display error and goto menu
        printf("Enter the name: ");
        scanf(" %[^\n]",n);
        __fpurge(stdin);
        for(i = 0; i <= addressBook->contactCount; i++)
        {
          flag = 1;
          int res = strcasecmp(addressBook->contacts[i].name,n);
          if(res == 0)
          {
            flag = 0;
            displaycontact(addressBook,i);
            return i;
          }
          //Giving suggestions to the user based on the entered subdtring to make the search easy
          char *found = strcasestr(addressBook->contacts[i].name,n);
          if(found != NULL)
          {
            printf("Is this the contact you are searching?\n");
            displaycontact(addressBook,i);
            printf("If yes enter 'Y'\n");//Getting confirmation from the user
            scanf(" %c",&ch);
            if(ch == 'Y'|| ch == 'y')
            {
            flag = 0;
            printf("Contact found\n");  
            return i;
            }
            else
            {
            found = NULL;
            continue;
            }
          }
        
        }
        if(flag == 1)  
        {
        printf("Entered name is invalid or not found.\n");
        }
        break;
        
        case 2:
         //Read the mobile number from the user and check whether it is present
        //yes->Print the complete details
        //No->Display error and goto menu
        printf("Enter the mobile number: ");
        scanf(" %[^\n]",p);
        __fpurge(stdin);
        for(i = 0; i <= addressBook->contactCount; i++)
        {
          flag = 1;
          int res = strcmp(addressBook->contacts[i].phone,p);
          if(res == 0)
          {
            flag = 0;
            displaycontact(addressBook,i);
            return i;
          }  
        }
        if(flag == 1)
        {
        printf("Entered Mobile number is invalid or not found.\n");
        }
        break;
        
        case 3:
        //Read the e-mail ID from the user and check whether it is present
        //yes->Print the complete details
        //No->Display error and goto menu
        printf("Enter the e-mail ID: ");
        scanf(" %[^\n]",e);
        __fpurge(stdin);
        for(i = 0; i <= addressBook->contactCount; i++)
        {
          flag = 1;
          int res = strcmp(addressBook->contacts[i].email,e);
          if(res == 0)
          {
            flag = 0;
            displaycontact(addressBook,i);
            return i;
          }  
          char *found = strcasestr(addressBook->contacts[i].email,e);
          if(found != NULL)
          {
            printf("Is this the contact you are searching?\n");
            displaycontact(addressBook,i);
            printf("If yes enter 'Y'\n");//Getting confirmation from the user
            scanf(" %c",&ch);
            if(ch == 'Y'|| ch == 'y')
            {
            flag = 0;
            printf("Contact found\n");  
            return i;
            }
            else
            {
            found = NULL;
            continue;
            }
          }
        }
        if(flag == 1)
        {
        printf("Entered e-mail ID is invalid or not found.\n");
        }
        break;


        default:
        printf("Please enter valid key(1-3)\n");
        
      }
    }
   return 0;
}

/*Function definition to display the menu for editing the contact*/
int editmenu()
{
  int key;
  printf("Which data do you like to edit: \n");
  printf(" 1.Name\n 2.Mobile No\n 3.e-mail ID\n 4.Exit menu\n");
  printf("Enter your choice: ");
  scanf("%d",&key);
  return key;
}

/*Function definition to sort the contact in alphabetical order irrespective of its case(lower/upper) */
void sortcontact(AddressBook *a,int c)
{
  int i,j; 
  
  for(i = 0; i < c; i++)
  {
    for(j = i+1; j < c; j++)
    {
      if(strcasecmp(a->contacts[i].name,a->contacts[j].name) > 0)//Bubble sorting technique is used to sort
      {
         a->temp = a->contacts[i];
         a->contacts[i] = a->contacts[j];
         a->contacts[j] = a->temp;
      }
    }
  }
}

/*Function to print dotted lines for aesthetics*/
void displayline()
{
  int i;
  for(i = 0; i <= 70; i++)
  printf("-");
  printf("\n");
}