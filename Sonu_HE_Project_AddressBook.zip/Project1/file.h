/*Prototypes of the functions saveContactsToFile and loadContactsFromFile being stored in contact.h 
user defined header file*/

#ifndef FILE_H
#define FILE_H

#include "contact.h"

void saveContactsToFile(AddressBook *addressBook);
void loadContactsFromFile(AddressBook *addressBook);

#endif
